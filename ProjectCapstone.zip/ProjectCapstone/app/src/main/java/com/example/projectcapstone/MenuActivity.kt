package com.example.projectcapstone

import android.content.Intent
import android.Manifest
import android.os.Bundle
import android.provider.MediaStore
import android.widget.ImageButton
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.core.content.ContextCompat
import android.content.pm.PackageManager
import androidx.core.app.ActivityCompat
import com.example.projectcapstone.R

@Suppress("OVERRIDE_DEPRECATION", "DEPRECATION")
class MenuActivity : ComponentActivity() {

    private val CAMERA_PERMISSION_REQUEST_CODE = 100

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_menu)

        // Temukan tombol dari layout
        val openCameraButton: ImageButton = findViewById(R.id.M_imagebutton_camera)

        // Set listener pada tombol
        openCameraButton.setOnClickListener {
            // Periksa apakah izin kamera sudah diberikan
            if (ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.CAMERA
                ) == PackageManager.PERMISSION_GRANTED) {
                // Jika sudah diberikan, buka kamera
                openCamera()
            } else {
                // Jika izin belum diberikan, minta izin
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.CAMERA),
                    CAMERA_PERMISSION_REQUEST_CODE
                )
            }
        }
    }

    // Fungsi untuk membuka kamera
    private fun openCamera() {
        val cameraIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        // Memeriksa apakah ada aplikasi yang dapat menangani Intent ini
        if (cameraIntent.resolveActivity(packageManager) != null) {
            // Jika ada aplikasi yang bisa menangani, jalankan intent
            startActivity(cameraIntent)
        } else {
            // Jika tidak ada aplikasi yang dapat menangani, tampilkan pesan
            Toast.makeText(this, "Tidak ada aplikasi kamera yang tersedia", Toast.LENGTH_SHORT).show()
        }
    }

    // Tangani permintaan izin dari pengguna
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == CAMERA_PERMISSION_REQUEST_CODE) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Jika izin diberikan, buka kamera
                openCamera()
            } else {
                // Jika izin ditolak, tampilkan pesan
                Toast.makeText(this, "Izin kamera ditolak", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
